package com.example.aiworkout

import android.content.SharedPreferences
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import android.media.AudioManager
import android.media.ToneGenerator
import kotlinx.coroutines.delay

data class Profile(val goal: String, val level: String, val days: Int, val gym: Boolean)
data class Ex(val name: String, val sets: Int, val reps: String)
data class Day(val title: String, val ex: List<Ex>)
data class Entry(val date: String, val title: String, val sets: Int, val volume: Int)

// ---------- Plan generator (rules-based; swap in an AI API later) ----------
private fun pool(gym: Boolean) = if (gym) mapOf(
    "push" to listOf("Bench Press", "Overhead Press", "Incline Dumbbell Press", "Tricep Pushdown", "Dips"),
    "pull" to listOf("Barbell Row", "Lat Pulldown", "Seated Cable Row", "Bicep Curl", "Face Pull"),
    "legs" to listOf("Squat", "Romanian Deadlift", "Leg Press", "Walking Lunge", "Calf Raise"),
    "core" to listOf("Plank", "Hanging Knee Raise", "Cable Crunch")
) else mapOf(
    "push" to listOf("Push-ups", "Pike Push-ups", "Diamond Push-ups", "Chair Dips", "Decline Push-ups"),
    "pull" to listOf("Table Inverted Row", "Superman", "Towel Row", "Reverse Snow Angels", "Band Curl"),
    "legs" to listOf("Bodyweight Squat", "Reverse Lunge", "Glute Bridge", "Step-ups", "Calf Raise"),
    "core" to listOf("Plank", "Dead Bug", "Bicycle Crunch")
)

fun makePlan(p: Profile): List<Day> {
    val pl = pool(p.gym)
    val sets = if (p.level == "Beginner") 3 else 4
    val reps = when (p.goal) { "Build muscle" -> "8-12"; "Lose fat" -> "12-15"; else -> "10-12" }
    val titles = when {
        p.days <= 3 -> List(p.days) { "Full Body" }
        p.days == 4 -> listOf("Upper", "Lower", "Upper", "Lower")
        else -> listOf("Push", "Pull", "Legs", "Push", "Pull", "Legs").take(p.days)
    }
    val cats = mapOf(
        "Full Body" to listOf("push", "pull", "legs", "core"),
        "Upper" to listOf("push", "pull", "push", "pull"),
        "Lower" to listOf("legs", "legs", "legs", "core"),
        "Push" to listOf("push", "push", "push", "core"),
        "Pull" to listOf("pull", "pull", "pull", "core"),
        "Legs" to listOf("legs", "legs", "legs", "core")
    )
    return titles.mapIndexed { d, t ->
        val used = mutableMapOf<String, Int>()
        val list = cats.getValue(t).map { c ->
            val n = used.getOrDefault(c, 0); used[c] = n + 1
            val options = pl.getValue(c)
            val name = options[(d + n) % options.size]
            Ex(name, if (c == "core") 3 else sets, if (c == "core") "30-45s" else reps)
        }.distinctBy { it.name }
        Day("Day ${d + 1}: $t", list)
    }
}

// ---------- Storage ----------
fun loadProfile(p: SharedPreferences): Profile? {
    val g = p.getString("goal", null) ?: return null
    return Profile(g, p.getString("level", "Beginner")!!, p.getInt("days", 3), p.getBoolean("gym", false))
}
fun saveProfile(p: SharedPreferences, x: Profile) = p.edit()
    .putString("goal", x.goal).putString("level", x.level).putInt("days", x.days).putBoolean("gym", x.gym).apply()
fun loadLogs(p: SharedPreferences): List<Entry> {
    val a = JSONArray(p.getString("logs", "[]"))
    return List(a.length()) { val o = a.getJSONObject(it); Entry(o.getString("d"), o.getString("t"), o.getInt("s"), o.getInt("v")) }
}
fun saveLogs(p: SharedPreferences, l: List<Entry>) {
    val a = JSONArray()
    l.forEach { a.put(JSONObject().put("d", it.date).put("t", it.title).put("s", it.sets).put("v", it.volume)) }
    p.edit().putString("logs", a.toString()).apply()
}

// ---------- UI ----------
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("fit", MODE_PRIVATE)
        setContent { MaterialTheme { App(prefs) } }
    }
}

@Composable
fun App(prefs: SharedPreferences) {
    var profile by remember { mutableStateOf(loadProfile(prefs)) }
    val logs = remember { mutableStateListOf<Entry>().apply { addAll(loadLogs(prefs)) } }
    var tab by remember { mutableIntStateOf(0) }
    var active by remember { mutableStateOf<Day?>(null) }
    var editing by remember { mutableStateOf(false) }
    val chat = remember { mutableStateListOf<Pair<String, String>>() }
    val pr = profile

    when {
        pr == null || editing -> Setup(pr) { profile = it; saveProfile(prefs, it); editing = false; tab = 0 }
        active != null -> Logger(active!!, onBack = { active = null }) { sets, vol ->
            logs.add(0, Entry(LocalDate.now().toString(), active!!.title, sets, vol))
            saveLogs(prefs, logs); active = null; tab = 1
        }
        else -> Scaffold(bottomBar = {
            NavigationBar {
                listOf("Plan", "Progress", "Coach", "Profile").forEachIndexed { i, t ->
                    NavigationBarItem(selected = tab == i, onClick = { if (i == 3) editing = true else tab = i },
                        icon = {}, label = { Text(t) }, alwaysShowLabel = true)
                }
            }
        }) { pad ->
            Box(Modifier.padding(pad).fillMaxSize()) {
                when (tab) {
                    0 -> PlanScreen(makePlan(pr)) { active = it }
                    1 -> ProgressScreen(logs)
                    else -> CoachScreen(prefs, pr, logs, chat)
                }
            }
        }
    }
}

@Composable
fun Setup(initial: Profile?, onDone: (Profile) -> Unit) {
    var goal by remember { mutableStateOf(initial?.goal ?: "Build muscle") }
    var level by remember { mutableStateOf(initial?.level ?: "Beginner") }
    var days by remember { mutableIntStateOf(initial?.days ?: 3) }
    var gym by remember { mutableStateOf(initial?.gym ?: false) }
    @Composable fun chips(opts: List<String>, sel: String, set: (String) -> Unit) =
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            opts.forEach { FilterChip(selected = sel == it, onClick = { set(it) }, label = { Text(it) }) }
        }
    Column(Modifier.fillMaxSize().safeDrawingPadding().padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Build your plan", style = MaterialTheme.typography.headlineMedium)
        Text("Goal"); chips(listOf("Build muscle", "Lose fat", "Stay fit"), goal) { goal = it }
        Text("Experience"); chips(listOf("Beginner", "Intermediate"), level) { level = it }
        Text("Days per week"); chips((2..6).map { it.toString() }, days.toString()) { days = it.toInt() }
        Text("Where do you train?"); chips(listOf("Home", "Gym"), if (gym) "Gym" else "Home") { gym = it == "Gym" }
        Spacer(Modifier.weight(1f))
        Button({ onDone(Profile(goal, level, days, gym)) }, Modifier.fillMaxWidth()) { Text("Generate plan") }
    }
}

@Composable
fun PlanScreen(plan: List<Day>, onStart: (Day) -> Unit) {
    LazyColumn(Modifier.safeDrawingPadding().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("Your week", style = MaterialTheme.typography.headlineMedium) }
        items(plan) { d ->
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(d.title, style = MaterialTheme.typography.titleMedium)
                    d.ex.forEach { Text("• ${it.name}  ${it.sets} × ${it.reps}") }
                    Button({ onStart(d) }, Modifier.padding(top = 8.dp)) { Text("Start workout") }
                }
            }
        }
    }
}

fun beep() {
    try { ToneGenerator(AudioManager.STREAM_ALARM, 80).startTone(ToneGenerator.TONE_PROP_BEEP2, 500) } catch (_: Exception) {}
}

@Composable
fun Logger(day: Day, onBack: () -> Unit, onFinish: (Int, Int) -> Unit) {
    val w = remember { mutableStateMapOf<String, String>() }
    val r = remember { mutableStateMapOf<String, String>() }
    val done = remember { mutableStateMapOf<String, Boolean>() }
    var rest by remember { mutableIntStateOf(0) }
    LaunchedEffect(rest > 0) {
        while (rest > 0) {
            delay(1000)
            if (rest > 0) { rest--; if (rest == 0) beep() }
        }
    }
    Column(Modifier.fillMaxSize().safeDrawingPadding()) {
        if (rest > 0) Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)) {
            Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Rest ${rest / 60}:${"%02d".format(rest % 60)}", Modifier.weight(1f), style = MaterialTheme.typography.titleLarge)
                OutlinedButton({ rest += 30 }) { Text("+30s") }
                Button({ rest = 0 }) { Text("Skip") }
            }
        }
        LazyColumn(Modifier.weight(1f).padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                TextButton(onBack) { Text("← Back") }
                Text(day.title, style = MaterialTheme.typography.headlineSmall)
            }
            day.ex.forEachIndexed { i, ex ->
                item { Text(ex.name + "  (${ex.sets} × ${ex.reps})", style = MaterialTheme.typography.titleMedium) }
                items((0 until ex.sets).toList()) { j ->
                    val k = "$i-$j"
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Set ${j + 1}", Modifier.width(48.dp))
                        OutlinedTextField(w[k] ?: "", { w[k] = it }, Modifier.weight(1f), label = { Text("kg") }, singleLine = true)
                        OutlinedTextField(r[k] ?: "", { r[k] = it }, Modifier.weight(1f), label = { Text("reps") }, singleLine = true)
                        Checkbox(done[k] == true, { done[k] = it; if (it) rest = 90 })
                    }
                }
            }
            item {
                Button({
                    var sets = 0; var vol = 0
                    done.forEach { (k, v) ->
                        if (v) { sets++; vol += ((w[k]?.toFloatOrNull() ?: 0f) * (r[k]?.toIntOrNull() ?: 0)).toInt() }
                    }
                    onFinish(sets, vol)
                }, Modifier.fillMaxWidth()) { Text("Finish workout") }
            }
        }
    }
}

@Composable
fun ProgressScreen(logs: List<Entry>) {
    LazyColumn(Modifier.safeDrawingPadding().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Text("Progress", style = MaterialTheme.typography.headlineMedium)
            Text("${logs.size} workouts • ${logs.sumOf { it.volume }} kg total volume")
            if (logs.isEmpty()) Text("Finish a workout to see it here.")
        }
        item { HealthCard() }
        items(logs) {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp)) {
                    Text(it.title, style = MaterialTheme.typography.titleSmall)
                    Text("${it.date} • ${it.sets} sets • ${it.volume} kg")
                }
            }
        }
    }
}

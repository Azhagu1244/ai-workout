package com.example.aiworkout

import android.content.SharedPreferences
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

// If you get a 404, change this to a current model name from ai.google.dev/gemini-api/docs/models
const val MODEL = "gemini-2.5-flash"

fun coachPrompt(p: Profile, logs: List<Entry>): String =
    "You are a concise, encouraging strength coach inside a workout app. " +
    "User: goal=${p.goal}, level=${p.level}, ${p.days} days/week, trains at ${if (p.gym) "gym" else "home"}. " +
    "Recent workouts: ${logs.take(5).joinToString { "${it.date} ${it.title} ${it.sets} sets ${it.volume}kg" }.ifEmpty { "none yet" }}. " +
    "Keep answers under 120 words. This is not medical advice; for pain or injury, tell them to see a professional."

suspend fun askCoach(key: String, system: String, history: List<Pair<String, String>>): String =
    withContext(Dispatchers.IO) {
        try {
            val contents = JSONArray()
            history.forEach { (role, text) ->
                contents.put(JSONObject().put("role", role).put("parts", JSONArray().put(JSONObject().put("text", text))))
            }
            val body = JSONObject()
                .put("system_instruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
                .put("contents", contents)
            val c = URL("https://generativelanguage.googleapis.com/v1beta/models/$MODEL:generateContent")
                .openConnection() as HttpURLConnection
            c.requestMethod = "POST"
            c.setRequestProperty("Content-Type", "application/json")
            c.setRequestProperty("x-goog-api-key", key)
            c.doOutput = true
            c.outputStream.use { it.write(body.toString().toByteArray()) }
            val ok = c.responseCode in 200..299
            val text = (if (ok) c.inputStream else c.errorStream).bufferedReader().readText()
            if (!ok) "Error ${c.responseCode}: ${text.take(200)}"
            else JSONObject(text).getJSONArray("candidates").getJSONObject(0)
                .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
        } catch (e: Exception) { "Couldn't reach the coach: ${e.message}" }
    }

@Composable
fun CoachScreen(prefs: SharedPreferences, p: Profile, logs: List<Entry>, chat: MutableList<Pair<String, String>>) {
    var key by remember { mutableStateOf(prefs.getString("key", "") ?: "") }
    var input by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    Column(Modifier.fillMaxSize().safeDrawingPadding().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("AI Coach", style = MaterialTheme.typography.headlineMedium)
        if (key.isBlank()) {
            Text("Paste a free Gemini API key (get one at aistudio.google.com/apikey). It stays on your phone.")
            OutlinedTextField(input, { input = it }, Modifier.fillMaxWidth(), label = { Text("API key") }, singleLine = true)
            Button({ key = input.trim(); prefs.edit().putString("key", key).apply(); input = "" }) { Text("Save key") }
        } else {
            LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (chat.isEmpty()) item { Text("Ask about your plan, form, swaps, or progress.") }
                items(chat) { (role, text) ->
                    Card(Modifier.fillMaxWidth()) {
                        Text((if (role == "user") "You: " else "Coach: ") + text, Modifier.padding(10.dp))
                    }
                }
                if (busy) item { Text("Coach is typing…") }
            }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(input, { input = it }, Modifier.weight(1f), placeholder = { Text("Ask your coach") })
                Button({
                    val q = input.trim()
                    if (q.isNotEmpty() && !busy) {
                        input = ""; chat.add("user" to q); busy = true
                        scope.launch {
                            val reply = askCoach(key, coachPrompt(p, logs), chat.toList())
                            chat.add("model" to reply); busy = false
                        }
                    }
                }) { Text("Send") }
            }
            TextButton({ key = ""; prefs.edit().remove("key").apply() }) { Text("Change API key") }
        }
    }
}

package com.example.aiworkout

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.health.connect.client.HealthConnectClient
import androidx.health.connect.client.PermissionController
import androidx.health.connect.client.permission.HealthPermission
import androidx.health.connect.client.records.HeartRateRecord
import androidx.health.connect.client.records.StepsRecord
import androidx.health.connect.client.request.AggregateRequest
import androidx.health.connect.client.time.TimeRangeFilter
import kotlinx.coroutines.launch
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId

@Composable
fun HealthCard() {
    val ctx = LocalContext.current
    val perms = setOf(
        HealthPermission.getReadPermission(StepsRecord::class),
        HealthPermission.getReadPermission(HeartRateRecord::class)
    )
    val available = HealthConnectClient.getSdkStatus(ctx) == HealthConnectClient.SDK_AVAILABLE
    val client = if (available) remember { HealthConnectClient.getOrCreate(ctx) } else null
    var status by remember { mutableStateOf("Connect to see today's steps and heart rate") }
    var steps by remember { mutableStateOf<Long?>(null) }
    var bpm by remember { mutableStateOf<Long?>(null) }
    var connected by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    fun load() {
        val c = client ?: return
        scope.launch {
            try {
                if (!c.permissionController.getGrantedPermissions().containsAll(perms)) return@launch
                connected = true
                val start = LocalDate.now().atStartOfDay(ZoneId.systemDefault()).toInstant()
                val r = c.aggregate(
                    AggregateRequest(
                        setOf(StepsRecord.COUNT_TOTAL, HeartRateRecord.BPM_AVG),
                        TimeRangeFilter.between(start, Instant.now())
                    )
                )
                steps = r[StepsRecord.COUNT_TOTAL]; bpm = r[HeartRateRecord.BPM_AVG]
                status = "Today from Health Connect"
            } catch (e: Exception) { status = "Couldn't read Health Connect data" }
        }
    }
    val launcher = rememberLauncherForActivityResult(PermissionController.createRequestPermissionResultContract()) { load() }
    LaunchedEffect(Unit) { load() }

    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text("Health", style = MaterialTheme.typography.titleSmall)
            if (!available) Text("Install or update Health Connect from Google Play to use this.")
            else {
                Text(status)
                if (connected) Text("Steps: ${steps ?: "–"}   Avg heart rate: ${bpm?.let { "$it bpm" } ?: "–"}")
                else Button({ launcher.launch(perms) }) { Text("Connect Health Connect") }
            }
        }
    }
}
